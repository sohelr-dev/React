<?php

class PrescriptionItems {
    public $id;
    public $prescription_id;
    public $medicine_id;
    public $dosage_id;
    public $duration_id;
    public $instruction_id;

    public function __construct($_id, $_prescription_id, $_medicine_id, $_dosage_id, $_duration_id, $_instruction_id) {
        $this->id = $_id;
        $this->prescription_id = $_prescription_id;
        $this->medicine_id = $_medicine_id;
        $this->dosage_id = $_dosage_id;
        $this->duration_id = $_duration_id;
        $this->instruction_id = $_instruction_id;
    }

    public function create() {
        global $db;
        $sql = "INSERT INTO prescription_items (id,prescription_id,medicine_id,dosage_id,duration_id,instruction_id) VALUES ('{$this->id}', '{$this->prescription_id}', '{$this->medicine_id}', '{$this->dosage_id}', '{$this->duration_id}', '{$this->instruction_id}')";
        if ($db->query($sql)) {
          return $db->insert_id;
        } else {
          return "Query failed: " . $db->error;
        }
    }

    public static function readAll() {
        global $db;
        $sql = "SELECT * FROM prescription_items";
        $res = $db->query($sql);
        if ($res) {
          return $res->fetch_all(MYSQLI_ASSOC);
        } else {
          return "Query failed: " . $db->error;
        }
    }

    public static function readById($id) {
        global $db;
        $id = (int)$id;
        $sql = "SELECT * FROM prescription_items WHERE id = $id";
        $res = $db->query($sql);
        if ($res) {
          return $res->fetch_assoc();
        } else {
          return "Query failed: " . $db->error;
        }
    }

    public function update($id) {
        global $db;
        $sql = "UPDATE prescription_items SET id='{$this->id}', prescription_id='{$this->prescription_id}', medicine_id='{$this->medicine_id}', dosage_id='{$this->dosage_id}', duration_id='{$this->duration_id}', instruction_id='{$this->instruction_id}' WHERE id = $id";
        if ($db->query($sql)) {
          if ($db->affected_rows > 0) {
            return "Update successful.";
          } else {
            return "No changes made or record not found.";
          }
        } else {
          return "Update failed: " . $db->error;
        }
    }

    public static function delete($id) {
        global $db;
        $sql = "DELETE FROM prescription_items WHERE id = $id";
        if ($db->query($sql)) {
          if ($db->affected_rows > 0) {
            return "Delete successful.";
          } else {
            return "No record found with ID $id.";
          }
        } else {
          return "Delete failed: " . $db->error;
        }
    }
}
